# Colorpicker plugin for Twitter Bootstrap

Originally written by [Stefan Petre](http://www.eyecon.ro/)

Read the documentation [here](http://mjaalnir.github.com/bootstrap-colorpicker/)


## Contributors

Please, before perform a Pull Request:

* Check that the index.html demos aren't broken (modify if necessary)
* Test your code in all modern browsers (and at least IE >= 9)

Thank you
