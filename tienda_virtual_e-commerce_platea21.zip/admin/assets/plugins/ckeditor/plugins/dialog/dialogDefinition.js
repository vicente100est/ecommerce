﻿/*
 Copyright (c) 2003-2013, CKSource - Frederico Knabben. Todos los derechos reservados.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
